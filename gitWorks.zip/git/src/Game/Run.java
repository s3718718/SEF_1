package Game;
import java.util.*;


public class Run 
{
	public final static int NUM_PLAYERS = 2;
	
	static Account[] accounts = new Account[NUM_PLAYERS];
	static int length = 0;
	
	public static void main(String[] args) {
		menu();
		Scanner scanner = new Scanner(System.in);
		Validate test = new Validate();
		int turn = 0;
		while (turn <= 0)
		{
			System.out.println();
			System.out.println("****Welcome to the 'Chess game'****");
			int i = 0;
			while(i < NUM_PLAYERS)
			{
				System.out.print("\nEnter number of turn: ");
				String input = scanner.nextLine();
				turn += test.isPositiveInt(input);
				if (turn == -1)
				{
					System.out.println("Invalid input!");
				}else
				{
					i++;
				}
			}
			turn /= NUM_PLAYERS;
		}
		Game game = new Game(turn);
		game.play();
	}
	
	static void menu()
	{
		Scanner scanner = new Scanner(System.in);
		Validate test = new Validate();
		int playerLogin = 0;
		while (playerLogin != NUM_PLAYERS)
		{
			System.out.println();
			System.out.println("****Welcome to the 'Chess game'****");
			System.out.println();
			System.out.println("Please enter your choice:\n1:		Login");
			System.out.println("2:		Register");
			String input = scanner.nextLine();
			int option = test.isPositiveInt(input);
			if (option == 1)
			{
				if(login())
				{
					playerLogin++;
				}else
				{
					menu();
				}
			}
			else if (option == 2)
			{
				register();
			}
			else 
			{
				System.out.println("Invalid input");
			}
		}
	}
	
	static boolean login()
	{
		Scanner scanner = new Scanner(System.in);
		boolean loginPass = false;
		int i = 0;
		while (i < 3 && loginPass == false)
		{
			System.out.println();
			System.out.println("****Login****");
			System.out.print("Enter ID: ");
			String id = scanner.nextLine();
			System.out.println();
			System.out.print("Enter the Password: ");
			String password = scanner.nextLine();
			System.out.println();
			for (int j = 0; j < length; j++)
			{
				if (id.equals(accounts[j].getId()))
				{
					if (password.equals(accounts[j].getPassword()))
					{
						loginPass = true;
						System.out.println("****Login Successfully****");
					}else
					{
						System.out.println("Login Failed!");
						i++;
					}
				}
			}
		}
		return loginPass;
	}
	
	static void register(){
		Scanner scanner = new Scanner(System.in);
		System.out.println("\n****Register****");
		boolean correctID = false;
		String id = "";
		while(correctID == false)
		{
			System.out.print("Enter your id: ");
			id = scanner.nextLine();
			boolean checkID = true;
			for (int i = 0; i < length; i++)
			{
				if (id.equals(accounts[i].getId()))
				{
					System.out.println("'" + id + "' is already in use\n");
					checkID = false;
				}
			}
			if(checkID)
			{
				correctID = true;
			}
		}
		System.out.print("\nEnter your password: ");
		String password = scanner.nextLine();
		accounts[length] = new Account(id,password);
		length++;
		System.out.println("\n****Account created****");
	}
}
