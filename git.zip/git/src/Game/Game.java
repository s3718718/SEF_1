package Game;

import java.util.Scanner;

import Piece.Bishop;
import Piece.Knight;
import Piece.Piece;
import Piece.Rook;
import Game.main_chessGui;


public class Game 
{
	public Board board;
	Board lastTurnBoard;
	int turns;
	int currentTurn;
	Player player1;
	Player player2;
	public Piece[] whiteSide;
	public Piece[] blackSide;
	public main_chessGui gui;
	public Piece selected;
	int currentPlayer;

	public Game(int turns)
	{
		this.turns = turns;
		board = new Board();
		whiteSide = new Piece[6];
		blackSide = new Piece[6];
		instantiatePiece();
		player1 = new Player(whiteSide, true);
		player2 = new Player(blackSide, false);
		currentTurn = 1;
		gui = new main_chessGui(6, 6, this, board);
		selected = null;
		currentPlayer = 0;
	}
	
	//Flow of the game
	public void play()
	{
		boolean inGame = true;
		while (inGame == true)
		{
			System.out.println();
			System.out.println("****The 'Chess Game'****");
			System.out.println("Turn " + currentTurn +" / "+ turns);
			System.out.println("Score: ");
			System.out.println("Player 1 at " + player1.getScore());
			System.out.println("Player 2 at " + player2.getScore());
			if ((currentTurn%2)==1)
			{
				System.out.println("****Player 1 turn****");
				currentPlayer = 0;
				playerTurn(player1);
			}
			else if ((currentTurn%2)==0)
			{
				System.out.println("****Player 2 turn****");
				currentPlayer = 1;
				playerTurn(player2);
			}
			if (player1.isInGame() == false || player2.isInGame() == false ||
					currentTurn > turns)
			{
				inGame = false;
			}
		}
		int player1Score = player1.getScore();
		int player2Score = player2.getScore();
		System.out.println("Game done\nThe Final Score is:");
		System.out.println("Player 1 at " + player1Score);
		System.out.println("Player 2 at " + player2Score + "\n");
		if(player1Score == player2Score)
		{
			System.out.println("Draw");
		}else if(player1Score > player2Score)
		{
			System.out.println("Player 1 Wins");
		}else
		{
			System.out.println("Player 2 Wins");
		}
	}

	public void playerTurn(Player player)
	{
		int state = 1;
		boolean endOfTurn = false;
		Scanner scanner = new Scanner(System.in);
		Validate test = new Validate();
		int pieceToMove = 0;
		int xPosition = 0;
		int yPosition = 0;
		while (endOfTurn == false)
		{
			System.out.println();
			board.display();
			System.out.println();
			if (state == 1)
			{
				int counter = 0;
				for (int i = 0; i < player.getPieces().length; i++)
				{
					Piece piece = player.getPiece(i);
					if (piece.getStatus() == true)
					{
						counter++;
						System.out.print(i+1+": " + piece.toString() + ", ");
					}
				}
				System.out.println();
				System.out.println("****Enter Piece to move****");
				String input = scanner.nextLine();
				pieceToMove = test.isPositiveInt(input);
				if (pieceToMove > -1 || pieceToMove <= counter)
				{
					state = 2;
				}
			}
			else if (state == 2){
				System.out.println("****Choose destination(x/y)****");
				System.out.println("****Enter x: ");
				String input = scanner.nextLine();
				xPosition = test.isPositiveInt(input);
				if (xPosition <= 5 || xPosition >= 0)
				{
					System.out.println("****Enter y: ");
					input = scanner.nextLine();
					yPosition = test.isPositiveInt(input);
					if (yPosition <= 5 || yPosition >= 0)
					{
						state = 3;
					}
				}
			}
			else if (state == 3)
			{
				boolean checkMove = tryMove(player.getPiece(pieceToMove-1),board.tiles[yPosition][xPosition]);
				if (checkMove == true)
				{
					System.out.println("\n****Move Successful****");
					endOfTurn = true;
				}
				else
				{
					state = 1;
				}
			}
		}
		nextTurn();
	}

	private void instantiatePiece()
	{
		whiteSide[0] = new Rook(board.tiles[0][0], true);
		whiteSide[1] = new Bishop(board.tiles[0][1], true);
		whiteSide[2] = new Knight(board.tiles[0][2], true);
		
		whiteSide[3] = new Knight(board.tiles[0][3], true);
		whiteSide[4] = new Bishop(board.tiles[0][4], true);
		whiteSide[5] = new Rook(board.tiles[0][5], true);
		
		blackSide[0] = new Rook(board.tiles[5][0], false);
		blackSide[1] = new Bishop(board.tiles[5][1], false);
		blackSide[2] = new Knight(board.tiles[5][2], false);
	
		blackSide[3] = new Knight(board.tiles[5][3], false);
		blackSide[4] = new Bishop(board.tiles[5][4], false);
		blackSide[5] = new Rook(board.tiles[5][5], false);
	}

	public boolean tryMove(Piece piece, Tile tile)
	{
		boolean moveCompleted = false;
		//Check board is there is any piece at this position
		if(piece.canMove(tile.getXPosition(), tile.getYPosition(), board))
		{
			if(tile.isPieceHere())
			{
				boolean targetPiece = tile.getPiece().getIsWhite();
				boolean thisPiece = piece.getIsWhite();
				if (targetPiece != thisPiece)
				{
					takePiece(tile, piece);
					piece.moveTo(tile);
					gui.pieceMove(piece, tile);
					moveCompleted = true;
				}
			}
			else 
			{
				piece.moveTo(tile);
				gui.pieceMove(piece, tile);
				moveCompleted = true;
			}
		}
		if(moveCompleted == false)
		{
			System.out.println("\n****Move Unsuccessful****");
		}
		return moveCompleted;
	}
	
	private void takePiece(Tile tile, Piece piece)
	{
		tile.getPiece().setStatus(false);
		tile.setPiece(null);
		if (piece.getIsWhite() == true)
		{
			player1.incrementScore();
		}else
		{
			player2.incrementScore();
		}
	}

	private void nextTurn()
	{
		currentTurn++;
	}
	
	public boolean selectOrMove(Piece piece)
	{
		boolean isSelect = false;
		if(currentPlayer == 0)
		{
			if(piece.getIsWhite())
			{
				if(!piece.equals(selected))
				{
					selected = piece;
				}else
				{
					isSelect = true;
				}
			}
		}else
		{
			if(!piece.getIsWhite())
			{
				if(!piece.equals(selected))
				{
					selected = piece;
				}else
				{
					isSelect = true;
				}
			}
		}
		return isSelect;
	}
}
