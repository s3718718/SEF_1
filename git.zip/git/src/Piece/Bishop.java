package Piece;
import java.util.ArrayList;

import Game.*;

public class Bishop extends Piece
{
	public Bishop(Tile tile, Boolean isWhite)
	{
		super(tile, isWhite);
	}

	@Override
	public boolean canMove(int targetX, int targetY, Board board)
	{
		boolean moveAllowed = false;
		int origX = tile.getXPosition();
		int origY = tile.getYPosition();
		if(origX != targetX || origY != targetY)
		{
			if(targetX < 6 && targetX >= 0)
			{
				if(targetY < 6 && targetY >= 0)
				{
					int absDispX = Math.abs(origX - targetX);
					int absDispY = Math.abs(origY - targetY);
					if(absDispX == absDispY && 
							absDispX <= 2 && absDispY <= 2)
					{
						Tile targetTile = board.getTile(targetX, targetY);
						if(targetTile.isPieceHere())
						{
							if(targetTile.getPiece().getIsWhite() != this.isWhite)
							{
								if(absDispX == 2 || absDispY == 2)
								{
									int xBetween = targetX - (targetX - origX)/2;
									int yBetween = targetY - (targetY - origY)/2;
									Tile betweenTile = board.getTile(xBetween, 
											yBetween);
									if(!betweenTile.isPieceHere())
									{
										moveAllowed = true;
									}
								}else
								{
									moveAllowed = true;
								}
							}
						}else
						{
							if(absDispX == 2 || absDispY == 2)
							{
								int xBetween = targetX - (targetX - origX)/2;
								int yBetween = targetY - (targetY - origY)/2;
								Tile betweenTile = board.getTile(xBetween, 
										yBetween);
								if(!betweenTile.isPieceHere())
								{
									moveAllowed = true;
								}
							}else
							{
								moveAllowed = true;
							}
						}
					}
				}
			}
		}
		return moveAllowed;
	}
	
	@Override
	public ArrayList<Tile> allMovements(Board board)
	{
		ArrayList<Tile> moveList = new ArrayList<Tile>();
		for(int i = -2; i < 3; i++)
		{
			for(int j = -2; j < 3; j++)
			{
				if(Math.abs(i) == Math.abs(j))
				{
					int targetX = i + tile.getXPosition();
					int targetY = j + tile.getYPosition();
					if(targetX < 6 && targetX >= 0)
					{
						if(targetY < 6 && targetY >= 0)
						{
							boolean checkTile = false;
							Tile targetTile = board.getTile(targetX, targetY);
							int origX = tile.getXPosition();
							int origY = tile.getYPosition();
							if(!targetTile.isPieceHere())
							{
								if(Math.abs(i) == 2 || Math.abs(j) == 2)
								{
									Tile middleTile = board.getTile(origX+(i/2), 
											origY+(j/2));
									if(!middleTile.isPieceHere())
									{
										checkTile = true;
									}
								}else
								{
									checkTile = true;
								}
							}else
							{
								if(targetTile.getPiece().getIsWhite() != this.isWhite)
								{
									if(Math.abs(i) == 2 || Math.abs(j) == 2)
									{
										Tile middleTile = board.getTile(origX+(i/2), 
												origY+(i/2));
										if(!middleTile.isPieceHere())
										{
											checkTile = true;
										}
									}else
									{
										checkTile = true;
									}
								}
							}
							if(checkTile == true)
							{
								moveList.add(targetTile);
							}
						}
					}
				}
			}
		}
		return moveList;
	}

	@Override
	public String display()
	{
		String display = "";
		if (isWhite == true)
		{
			display += "B";
		}
		else
		{
			display += "b";
		}
		return display;
	}
	
	@Override
	public String toString()
	{
		String bishopString = "Bishop [" + tile.getXPosition() + "][" +
				tile.getYPosition() + "]";
		return bishopString;
	}
}
