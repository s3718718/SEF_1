package Piece;

import java.util.ArrayList;
import Game.*;

public class Knight extends Piece
{
	public Knight(Tile tile, Boolean isWhite)
	{
		super(tile, isWhite);
	}

	@Override
	public boolean canMove(int targetX, int targetY, Board board)
	{
		boolean moveAllowed = false;
		if(targetX < 6 && targetX >= 0)
		{
			if(targetY < 6 && targetY >= 0)
			{
				int origX = tile.getXPosition();
				int origY = tile.getYPosition();
				int dispX = origX - targetX;
				int dispY = origY - targetY;
				if(Math.abs(dispX) == 1 && Math.abs(dispY) == 2 ||
						Math.abs(dispX) == 2 && Math.abs(dispY) == 1)
				{
					Tile targetTile = board.getTile(targetX, targetY);
					if(targetTile.isPieceHere())
					{
						if(targetTile.getPiece().getIsWhite() != this.isWhite)
						{
							moveAllowed = true;
						}
					}else
					{
						moveAllowed = true;
					}
				}
			}
		}
		return moveAllowed;
	}
	
	@Override
	public ArrayList<Tile> allMovements(Board board)
	{
		ArrayList<Tile> moveList = new ArrayList<Tile>();
		for(int i = -2; i < 3; i++)
		{
			for(int j = -2; j < 3; j++)
			{
				if(Math.abs(i) == 1 && Math.abs(j) == 2 ||
						Math.abs(i) == 2 && Math.abs(j) == 1)
				{
					int targetX = i + tile.getXPosition();
					int targetY = j + tile.getYPosition();
					if(targetX < 6 && targetX >= 0)
					{
						if(targetY < 6 && targetY >= 0)
						{
							Tile targetTile = board.getTile(targetX, targetY);
							if(!targetTile.isPieceHere())
							{
								moveList.add(targetTile);
							}else
							{
								if(targetTile.getPiece().getIsWhite() != this.isWhite)
								{
									moveList.add(targetTile);
								}
							}
						}
					}
				}
			}
		}
		return moveList;
	}

	@Override
	public String display()
	{
		String display = "";
		if (isWhite == true)
		{
			display += "K";
		}
		else
		{
			display += "k";
		}
		return display;
	}
	
	@Override
	public String toString()
	{
		String knightString = "Knight [" + tile.getYPosition() + "][" +
				tile.getXPosition() + "]";
		return knightString;
	}
}
