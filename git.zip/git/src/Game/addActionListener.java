package Game;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class addActionListener implements ActionListener {
	Game game;
	Board board;
	int x;
	int y;
	boolean selected;
	
	public addActionListener(Game game, Board board, int x, int y) {
		// TODO Auto-generated constructor stub
		this.game = game;
		this.board = board;
		this.x = x;
		this.y = y;
		this.selected = false;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		Tile targetTile = board.getTile(x, y);
		if(targetTile.isPieceHere())
		{
			selected = game.selectOrMove(targetTile.getPiece());
			if(selected)
			{
				game.tryMove(targetTile.getPiece(), targetTile);
			}
		}else if(selected)
		{
			game.tryMove(targetTile.getPiece(), targetTile);
		}
	}

}
