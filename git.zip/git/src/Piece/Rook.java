package Piece;
import java.util.ArrayList;

import Game.*;

public class Rook extends Piece
{
	public Rook(Tile tile, Boolean isWhite)
	{
		super(tile, isWhite);
	}

	@Override
	public boolean canMove(int targetX, int targetY, Board board)
	{
		boolean moveAllowed = false;
		if(targetX < 6 && targetX >= 0)
		{
			if(targetY < 6 && targetY >= 0)
			{
				int origX = tile.getXPosition();
				int origY = tile.getYPosition();
				int absDispX = Math.abs(origX - targetX);
				int absDispY = Math.abs(origY - targetY);
				if(absDispX <= 2 && absDispY <= 2)
				{
					if(targetX == origX && targetY != origY ||
							targetX != origX && targetY == origY)
					{
						Tile targetTile = board.getTile(targetX, targetY);
						if(targetTile.isPieceHere())
						{
							Piece test = targetTile.getPiece();
							if(targetTile.getPiece().getIsWhite() != this.isWhite)
							{
								if(absDispX == 2 || absDispY == 2)
								{
									int xBetween = targetX - (targetX - origX)/2;
									int yBetween = targetY - (targetY - origY)/2;
									Tile betweenTile = board.getTile(xBetween, 
											yBetween);
									if(!betweenTile.isPieceHere())
									{
										moveAllowed = true;
									}
								}else
								{
									moveAllowed = true;
								}
							}
						}else
						{
							if(absDispX == 2 || absDispY == 2)
							{
								int xBetween = targetX - (targetX - origX)/2;
								int yBetween = targetY - (targetY - origY)/2;
								Tile betweenTile = board.getTile(xBetween, 
										yBetween);
								if(!betweenTile.isPieceHere())
								{
									moveAllowed = true;
								}
							}else
							{
								moveAllowed = true;
							}
						}
					}
				}
			}
		}
		return moveAllowed;
	}
	
	@Override
	public ArrayList<Tile> allMovements(Board board)
	{
		ArrayList<Tile> moveList = new ArrayList<Tile>();
		for(int i = -2; i < 3; i++)
		{
			for(int j = -2; j < 3; j++)
			{
				int origX = tile.getXPosition();
				int origY = tile.getYPosition();
				int targetX = origX + i;
				int targetY = origY + j;
				if(targetX < 6 && targetX >= 0)
				{
					if(targetY < 6 && targetY >= 0)
					{
						if(targetX == origX && targetY != origY ||
								targetX != origX && targetY == origY)
						{
							boolean checkTile = false;
							Tile targetTile = board.getTile(targetX, targetY);
							if(Math.abs(i) == 2)
							{
								Tile middleTile = board.getTile
										(origX+(i/2), targetY);
								if(!middleTile.isPieceHere())
								{
									if(!targetTile.isPieceHere())
									{
										checkTile = true;
									}else
									{
										if(targetTile.getPiece().getIsWhite() 
												!= this.isWhite)
										{
											checkTile = true;
										}
									}	
								}
							}else if(Math.abs(j) == 2)
							{
								Tile middleTile = board.getTile
										(targetX, origY+(j/2));
								if(!middleTile.isPieceHere())
								{
									if(!targetTile.isPieceHere())
									{
										checkTile = true;
									}else
									{
										if(targetTile.getPiece().getIsWhite() 
												!= this.isWhite)
										{
											checkTile = true;
										}
									}	
								}
							}else
							{
								if(!targetTile.isPieceHere())
								{
									checkTile = true;
								}else
								{
									if(targetTile.getPiece().getIsWhite() != this.isWhite)
									{
										checkTile = true;
									}
								}
							}
							if(checkTile == true)
							{
								moveList.add(targetTile);
							}
						}
					}
				}
			}
		}
		return moveList;
	}

	@Override
	public String display()
	{
		String display = "";
		if (isWhite == true)
		{
			display += "R";
		}
		else
		{
			display += "r";
		}
		return display;
	}
	
	@Override
	public String toString()
	{
		String rookString = "Rook [" + tile.getXPosition() + "][" +
				tile.getYPosition() + "]";
		return rookString;
	}
}
