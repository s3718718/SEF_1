package Game;

public class Board {
	public Tile[][] tiles;

	public Tile[][] getBoard() {
		return tiles;
	}

	public Board(){
		//Instantiate tiles
		tiles = new Tile[6][6];
		for (int xPosition = 0; xPosition < 6; xPosition++)
		{
			for (int yPosition = 0; yPosition < 6; yPosition++)
			{
				tiles[xPosition][yPosition] = new Tile(xPosition, yPosition);
			}
		}
	}

	public Tile getTile(int xPosition, int yPosition)
	{
		return tiles[xPosition][yPosition];
	}

	public void display(){
		System.out.print("\n| |0|1|2|3|4|5|");
		for (int i = 0; i < 6; i++)
		{
			System.out.println();
			System.out.print("|"+i+"|");
			for (int y =0; y < 6; y++)
			{
				tiles[i][y].display();
				System.out.print("|");
			}
		}
		System.out.println();
	}
}
