package Game;
import Piece.*;

public class Tile 
{
	private Piece piece;
	private int xPosition;
	private int yPosition;

	public Tile(int xPosition, int yPosition)
	{
		this.xPosition = xPosition;
		this.yPosition = yPosition;
	}

	public int getXPosition()
	{
		return xPosition;
	}
	
	public int getYPosition()
	{
		return yPosition;
	}

	public boolean isPieceHere()
	{
		boolean pieceHere = false;
		if (piece != null)
		{
			pieceHere = true;
		}
		return pieceHere;
	}

	public Piece getPiece()
	{
		return piece;
	}

	public void setPiece(Piece piece)
	{
		this.piece = piece;
	}

	public void display()
	{
		if (piece == null)
			System.out.print(" ");
		else piece.display();
	}
}
