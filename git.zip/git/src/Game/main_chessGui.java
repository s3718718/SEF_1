package Game;

import javax.swing.JFrame; //imports JFrame library
import javax.swing.JLabel;
import javax.swing.JButton; //imports JButton library

import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout; //imports GridLayout library

import Game.Game;
import Game.Board;
import Piece.Piece;

public class main_chessGui extends JFrame{

	JFrame frame = new JFrame(); // creates frame
	JButton[][] grid; // names the grid of buttons
	
	
	int rowSize = 0;
	int playerSide = 0;
	int playerRow = 0;
	public int width = 0;

	public main_chessGui(int width, int length, Game game, Board board) 
	{ // constructor
		super("The Chess Game");
		this.setLayout(new GridLayout(width, length)); // set layout
		this.setBounds(100, 100, 640, 480);
		this.
		grid = new JButton[width][length]; // allocate the size of grid

		// Main Loop
		for (int y = 0; y < length; y++) {
			for (int x = 0; x < width; x++) {
				JButton button = new JButton("");
				grid[x][y] = button; // creates new button 
				grid[x][y].addActionListener(new addActionListener(game, board, x, y));
				if(y%2 == 0)
				{
					if(x%2 == 0)
					{
						grid[x][y].setBackground(Color.darkGray);
					}
				}else
				{
					if(x%2 == 1)
					{
						grid[x][y].setBackground(Color.darkGray);
					}
				}
				this.add(grid[x][y]); // adds button to grid at coordinates (x,y)


				rowSize++;
			}
		}
		pieceIntialPlace();
		this.grid[0][0].revalidate();
		this.grid[0][0].repaint();
		this.revalidate();
		this.repaint();

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Ensure Frame Closes
		this.setVisible(true); // makes frame visible
	}

/*	private void piecePlacement() {

		for (int i = 0; i < playerSide; i++) {
			for (int j = 0; j < playerRow; j++) {
				for (int k = 0; k < rowSize; k++) {
					if(rowSize == 1){
						grid[0][0]
					}
					if(rowSize == 2){
						
					}
					if(rowSize == 3){
						
					}
					if(rowSize == 4){
						
					}
					if(rowSize == 5){
						
					}
					if(rowSize == 6){
						
					}
				}
			}

		}

		}*/

	private void pieceIntialPlace(){

		for(int i = 0; i < 12; i++){
			for(int j = 0; j < 12; j++){
				for(int rowLength = 0; rowLength < this.width; rowLength++)
				{

				if(j == 1){
					if(rowLength == 1){
						grid[i][j].setText("WR");
					}

					if(rowLength == 2){
						grid[i][j].setText("WB");
					}

					if(rowLength == 3){
						grid[i][j].setText("WK");
					}

					if(rowLength == 4){
						grid[i][j].setText("WK");
					}

					if(rowLength == 5){
						grid[i][j].setText("WB");
					}

					if(rowLength == 6){
						grid[i][j].setText("WR");
					}
				}

				if(j == 6){
					if(rowLength == 1){
						grid[i][j].setText("br");
					}

					if(rowLength == 2){
						grid[i][j].setText("bb");
					}

					if(rowLength == 3){
						grid[i][j].setText("bk");
					}

					if(rowLength == 4){
						grid[i][j].setText("bk");
					}

					if(rowLength == 5){
						grid[i][j].setText("bb");
					}

					if(rowLength == 6){
						grid[i][j].setText("br");
					}
				}
			}
			}


		}
	}
		
		
		public void pieceMove(Piece piece, Tile target)
		{
			if(piece.getIsWhite())
			{
				grid[target.getXPosition()][target.getYPosition()]
						.setText("W" + piece.display());
			}else
			{
				grid[target.getXPosition()][target.getYPosition()]
					.setText("b" + piece.display());
			}
			this.revalidate();
			this.repaint();
		}




	}
